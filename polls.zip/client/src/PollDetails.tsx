import { ChangeEvent, Component, MouseEvent } from "react";
import { Poll, parsePoll} from "./poll";
import React from "react";
import { isRecord } from "./record";

type DetailsProps = {
    name: string,
    onBackClick: () => void;
}

type DetailsState = {
    now: number,
    poll: Poll | undefined,
    voter: string,
    vote: string,
    votes: Map<string, string>,
    voted: string,
    total: number,
    results: number[],
    error: string;
}

// Shows an Individual poll and allows voting (if ongoing)
export class PollDetails extends Component<DetailsProps, DetailsState> {

    constructor (props: DetailsProps) {
        super(props);

        this.state = {now: Date.now(), poll: undefined,
                        voter: '', vote: '', votes: new Map(), voted: '', 
                        total: 0, results: [], error: ''};
    }

    componentDidMount = (): void => {
        this.doRefreshClick();
    }
    
    render = (): JSX.Element => {
        if (this.state.poll !== undefined) {
            if (this.state.poll.time <= this.state.now) {
                this.doResultsChange(this.state.poll)
                return this.renderCompleted(this.state.poll);
                
            } else {
                return this.renderOngoing(this.state.poll);
            }
        }
        return <div></div>
    }

    renderCompleted = (poll: Poll): JSX.Element => {
        const min = (Math.round((poll.time - this.state.now) / 60 / 100) / 10) * -1;
        return (
            <div>
                <h1>{poll.name}</h1>
                <div>
                    <p><i>Closed {min} minutes ago.</i></p>
                    <ul>{this.renderOptionsCompleted()}</ul>
                </div>
                <div>
                    <button type='button' onClick={this.doBackClick}>Back</button>
                    <button type='button' onClick={this.doRefreshClick}>Refresh</button>
                </div>
            </div>
        )
    }

    renderOngoing = (poll: Poll): JSX.Element => {
        const min = Math.round((poll.time - this.state.now) / 60 / 100) /10;
        return (
            <div>
                <h1>{poll.name}</h1>
                <div>
                    <p><i>Closes in {min} minutes...</i></p>
                    <ul>{this.renderOptionsOngoing()}</ul>
                    Voter Name: <input type='text' value={this.state.voter} onChange={this.doVoterChange}/>
                </div>
                <div>
                    <button type='button' onClick={this.doBackClick}>Back</button>
                    <button type='button' onClick={this.doRefreshClick}>Refresh</button>
                    <button type='button' onClick={this.doVoteClick}>Vote</button>
                </div>
                {this.state.voted}
            </div>
        )
    }

    renderOptionsCompleted = (): JSX.Element[] => {
        if (this.state.poll !== undefined) {
            const options = [];
            for (const option of this.state.poll.options) {
                options.push(<li key={option}>{this.state.results.at(this.state.poll.options.indexOf(option))}% - {option}</li>);
            }
            return options;
        }
        return [];
    }

    doResultsChange = (poll: Poll): void => {
        const percent = [];
        const options = poll.options;
        const votes = this.state.votes.values()
        const voteCount = Array(options.length).fill(0);
        for (const vote of votes) {
            const choice = options.indexOf(vote);
            if (choice !== -1) {
                voteCount[choice] +=  1;
            }
        }
        for (const count of voteCount) {
            percent.push(Math.round((count / this.state.total) * 100));
        }
        this.setState({results: percent});
    }

    renderOptionsOngoing = (): JSX.Element[] => {
        if (this.state.poll !== undefined) {
            const options = [];
            for (const option of this.state.poll.options) {
                options.push(<li key={option}>
                <input type="radio" value={option} checked={this.state.vote === option}
                    onChange={(evt) => this.doOptionsClick(evt, option)}/> 
                <label htmlFor={option}>{option}</label> 
            </li> );
            }
            return options;
        }
        return [];
    }

    doVoterChange = (evt: ChangeEvent<HTMLInputElement>): void => {
        this.setState({voter: evt.target.value});
    }

    doBackClick = (): void => {
        this.props.onBackClick(); // tell the parent this was clicked
    }

    doRefreshClick = (): void => {
        fetch('/api/getPoll?name=' + this.props.name)
          .then(this.doGetResp)
          .catch(() => this.doGetError("failed to connect to server"));
    };

    doGetResp = (res: Response): void => {
        if (res.status === 200) {
          res.json().then(this.doGetJson)
              .catch(() => this.doGetError("200 res is not JSON"));
        } else if (res.status === 400) {
          res.text().then(this.doGetError)
              .catch(() => this.doGetError("400 response is not text"));
        } else {
          this.doGetError(`bad status code from /api/getPoll: ${res.status}`);
        }
      };
    
    doGetJson = (data: unknown): void => {
        if (!isRecord(data)) {
            console.error("bad data from /api/getPoll: not a record", data);
            return;
        }

        this.doPollChange(data);
    }

    doPollChange = (data: {poll?: unknown}): void => {
        const poll = parsePoll(data.poll);
        if (poll !== undefined) {
            this.setState({poll: poll, now: Date.now(), error: ""});
        } else {
            console.error("poll from /api/getPoll did not parse", data.poll)
        }
    };

    doGetError = (msg: string): void => {
        console.error(`Error fetching /api/getPoll: ${msg}`);
    };

    doVoteClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
        if (this.state.votes.delete(this.state.voter)) {
            this.state.votes.set(this.state.voter, this.state.vote);
        } else {
            this.state.votes.set(this.state.voter, this.state.vote);
        }
        this.setState({voted: 'Recorded vote of "' + this.state.voter + '" as "' + this.state.vote + '"', total: this.state.total + 1})
    }

    doOptionsClick = (_evt: ChangeEvent<HTMLInputElement>, option: string): void => {
        this.setState({vote: option});
    }
}