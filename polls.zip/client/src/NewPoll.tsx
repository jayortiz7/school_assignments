import React, { ChangeEvent, MouseEvent} from "react";
import { Component } from "react";
import { isRecord } from "./record";

type NewPollProps = {
    onCreateClick: (pollName: string) => void;
    onBackClick: () => void;
}

type NewPollState = {
    name: string,
    time: string,
    options: string;
    error: string;
}

// Allows the user to creat a new poll.
export class NewPoll extends Component<NewPollProps, NewPollState> {
    constructor(props: NewPollProps) {
        super(props);
        this.state = {name: '', time: '10', options: '', error: ''}
    }

    render = (): JSX.Element => {
        return (
            <div><h1>New Poll</h1>
                <div>
                    <label>Name:</label>
                    <input type='text' value={this.state.name} onChange={this.doNameChange}/>
                    <br/>
                    <label>Minutes:</label>
                    <input type='number' value={this.state.time} onChange={this.doTimeChange}/>
                    <br/>
                    <label htmlFor='textbox'>Options (one per line, minimum 2 lines):</label>
                    <br/>
                    <textarea id='textbox' rows={3} cols={40} value={this.state.options}
                        onChange={this.doOptionsChange}></textarea>
                </div>

                <div>
                    <button onClick={this.doCreateClick}>Create</button>
                    <button onClick={this.doBackClick}>Back</button>
                </div>
                {this.renderError()}
            </div>
        )
    }

    renderError = (): JSX.Element => {
        if (this.state.error.length === 0) {
            return <div></div>;
        } else {
            const style = {width: '300px', backgroundColor: 'rgb(246,194,192)',
                border: '1px solid rgb(137,66,61)', borderRadius: '5px', padding: '5px' };
            return (<div style={{marginTop: '15px'}}>
                <span style={style}><b>Error</b>: {this.state.error}</span>
            </div>);
        }
    };

    doNameChange = (evt: ChangeEvent<HTMLInputElement>): void => {
        this.setState({name: evt.target.value});
    }

    doTimeChange = (evt: ChangeEvent<HTMLInputElement>): void => {
        this.setState({time: evt.target.value});
    }

    doOptionsChange = (evt: ChangeEvent<HTMLTextAreaElement>): void => {
        this.setState({options: evt.target.value});
    }

    doCreateClick = (): void => {
        // Verify that the user entered all required information
        if (this.state.name.length === 0 || 
            this.state.time.length === 0 ||
            this.state.options.length === 0) {
            this.setState({error: 'a required field is missing.'});
            return;
        }

        // Verify that time is a number
        const time = parseFloat(this.state.time);
        if (isNaN(time) || time < 1 || Math.floor(time) !== time) {
            this.setState({error: "time is not a positive integer"});
            return;
        }
        const options = this.state.options.split('\n');
        if (options.length < 2) {
            this.setState({error: 'please format and enter valid poll options'});
        } else {
            // Ask the app to start this poll (adding it to the list).
            const args = {name: this.state.name, time: time, 
                options: options}
            fetch('/api/addPoll', {
                method: 'POST', body: JSON.stringify(args),
                headers: {"Content-Type": "application/json"}})
                .then(this.doAddResp)
                .catch(() => this.doAddError('failed to connect to server'));
        }
    }

    doAddResp = (resp: Response): void => {
        if (resp.status === 200) {
            resp.json().then(this.doAddJson)
                .catch(() => this.doAddError('200 response is not JSON'));
        } else if (resp.status === 400) {
            resp.text().then(this.doAddError)
                .catch(() => this.doAddError('400 response is not text'));
        } else {
            this.doAddError(`bad status code from /api/addPoll ${resp.status}`);
        }
    }

    doAddJson = (data: unknown): void => {
        if (!isRecord(data)) {
          console.error("bad data from /api/addPoll: not a record", data);
          console.log('not record')
          return;
        }
    
        this.props.onCreateClick(this.state.name);  // show the poll created
      };
    
      doAddError = (msg: string): void => {
        this.setState({error: msg})
      };
    
      doBackClick = (_: MouseEvent<HTMLButtonElement>): void => {
        this.props.onBackClick();  // tell the parent this was clicked
      };
}