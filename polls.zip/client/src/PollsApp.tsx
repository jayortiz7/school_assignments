import React, { Component } from "react"; //ChangeEvent, MouseEvent
import { NewPoll } from "./NewPoll";
import { PollDetails } from "./PollDetails";
import { PollList } from "./PollList";
//import { isRecord } from './record'; 


// TODO: When you're ready to get started, you can remove all the code below and
// start with this blank application:
//
type PollsAppState = {
  display: string;
  pollName?: string;
}

/** Displays the UI of the Polls application. */
export class PollsApp extends Component<{}, PollsAppState> {

  constructor(props: {}) {
    super(props);

    this.state = {display: 'main'};
  }
  
  render = (): JSX.Element => {
    if (this.state.display === 'main') {
      return <PollList onNewClick={() => this.setState({display: 'newpoll'})} 
        onPollClick={(name) => this.setState({pollName: name, display: 'currentpoll'})}/>;
    } else if (this.state.display === 'newpoll') {
      return <NewPoll onCreateClick={(name) => this.setState({pollName: name, display: 'currentpoll'})} 
        onBackClick={this.doBackClick}/>
    } else if (this.state.display === 'currentpoll') {
      if (this.state.pollName !== undefined) {
        return  <PollDetails name={this.state.pollName} onBackClick={this.doBackClick}/>
      }
    } 
    return <div></div>
  };

  doBackClick = (): void => {
    this.setState({display: 'main'});
  }
}