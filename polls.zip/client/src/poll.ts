import { isRecord } from "./record";

// instance of individual poll
export type Poll = {
    name: string;
    time: number;
    options: string[];
};

/**
 * Parses unknown data into a Poll. Will log an error and return undefined if it
 * is not a valid Poll.
 * @param val unkown data to parse into a Poll
 * @returns Poll if val is a valid Poll and undefined otherwise
 */
export const parsePoll = (val: unknown): undefined | Poll => {
    if (!isRecord(val)) {
        console.error('not a poll,', val);
        return undefined;
    }
    if (typeof val.name !== 'string') {
        console.error('not a poll: missing name', val);
        return undefined;
    }
    if (typeof val.time !== 'number') {
        console.error('not a poll: missing time', val);
        return undefined;
    }
    if (!Array.isArray(val.options)) {
        console.error('not a poll: missing options', val);
        return undefined;
    }

    return {name: val.name, time: val.time, options: val.options}
}
