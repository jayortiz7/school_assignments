import { Component, MouseEvent } from "react";
import { Poll, parsePoll } from "./poll";
import React from "react";
import { isRecord } from "./record";

type ListProps = {
    onNewClick: () => void,
    onPollClick: (name: string) => void
};

type ListState = {
    now: number,    // current time when rendering
    openPolls: Poll[]
    closedPolls: Poll[]
}

// Shows the list of all the auctions
export class PollList extends Component<ListProps, ListState> {

    constructor(props: ListProps) {
        super(props)
        this.state = {now: Date.now(), openPolls: [], closedPolls: []}
    }

    componentDidMount = (): void => {
        this.doRefreshClick();
    }

    componentDidUpdate = (prevProps: ListProps): void => {
        if (prevProps !== this.props) {
            this.setState({now: Date.now()});   // force a refresh
        }
    };

    render = (): JSX.Element => {
        return (
            <div>
                <div>
                    <h1>Current Polls</h1>
                </div>
                <div>
                    <h2>Still Open</h2>
                    {this.renderStillOpen()}
                </div>
                <div>
                    <h2>Closed</h2>
                    {this.renderClosed()}
                </div>
                <div>
                    <button type='button' onClick={this.doRefreshClick}>Refresh</button>
                    <button type='button' onClick={this.doNewClick}>New Poll</button>
                </div>
            </div>);
    };

    renderStillOpen = (): JSX.Element => {
        const open: JSX.Element[] = [];
        for (const poll of this.state.openPolls) {
            const min = (poll.time - this.state.now) / 60 / 100;
            const desc = 
            <span> - {Math.round(min)/10} minutes remaining</span>;
            open.push(
                <li key={poll.name}>
                    <a href='#' onClick={(evt) => this.doPollClick(evt, poll.name)}>{poll.name}</a>
                    {desc}
                </li>
            )
        }
        return <ul>{open}</ul>;
    }

    renderClosed = (): JSX.Element => {
        const closed: JSX.Element[] = [];
        for (const poll of this.state.closedPolls) {
            const min = ((poll.time - this.state.now) / 60 / 100) * -1;
            const desc =
            <span> - closed {Math.round(min)/10} minutes ago</span>;
            closed.push(
                <li key={poll.name}>
                    <a href='#' onClick={(evt) => this.doPollClick(evt, poll.name)}>{poll.name}</a>
                    {desc}
                </li>
            )
        }
        return <ul>{closed}</ul>
    }

    doListResp = (res: Response): void => {
        if (res.status === 200) {
            res.json().then(this.doListJson)
                .catch(() => this.doListError('200, response is not JSON'));
        } else if (res.status === 400) {
            res.text().then(this.doListError)   // not sure what text is, will need to change
                .catch(() => this.doListError('400, response is not text'));
        } else {
            this.doListError(`bad status code from /api/list: ${res.status}`);
        }
    }

    doListJson = (data: unknown): void => {
        if (!isRecord(data)) {
            console.error("bad data from /api/list: not a record", data);
            return;
        }
        if (!Array.isArray(data.polls)) {
            console.error("bad data from /api/list: polls is not an array", data);
            return;
          }

          const open: Poll[] = [];
          const closed: Poll[] = [];
          for (const val of data.polls) {
            const poll = parsePoll(val);
            if (poll === undefined) {
                return;
            } else if (poll.time <= Date.now()) {
                closed.push(poll);
            } else {
                open.push(poll);
            }
          }
          this.setState({openPolls: open, closedPolls: closed, now: Date.now()});  // fix time also
    }

    doListError = (msg: string): void => {
        console.error(`Error fetching /api/list: ${msg}`);
    };
    
    doRefreshClick = (): void => {
        fetch("/api/listPolls").then(this.doListResp)
            .catch(() => this.doListError("failed to connect to server"));
    };

    doNewClick = (_evt: MouseEvent<HTMLButtonElement>,): void => {
        this.props.onNewClick();  // tell the parent to show the new poll
    };

    doPollClick = (evt: MouseEvent<HTMLAnchorElement>, name: string): void => {
        evt.preventDefault();
        this.props.onPollClick(name);
    };
}