import * as assert from 'assert';
import * as httpMocks from 'node-mocks-http';
import { listPolls, addPoll, advanceTimeForTesting, resetForTesting, getPoll } from './routes';


describe('routes', function() {

  it('listPolls', function() {
    // straight line code:
    const req1 = httpMocks.createRequest(
      {method: 'GET', url: '/api/listPolls', query: {}});
    const res1 = httpMocks.createResponse();
    listPolls(req1, res1);

    assert.strictEqual(res1._getStatusCode(), 200);
    assert.deepStrictEqual(res1._getData(), {polls: []})

    const req2 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPoll',
       body: {name: 'lunch', time: 10, 
        options: ['pizza', 'burger', 'nothing']}});
    const res2 = httpMocks.createResponse();
    addPoll(req2, res2);
    assert.strictEqual(res2._getStatusCode(), 200);
    assert.deepStrictEqual(res2._getData().poll.name, 'lunch');
    assert.deepStrictEqual(res2._getData().poll.options, 
      ['pizza', 'burger', 'nothing']);
    
    const req3 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPoll',
       body: {name: 'protein', time: 5, 
        options: ['chicken', 'beef', 'pork']}});
    const res3 = httpMocks.createResponse();
    addPoll(req3, res3);
    assert.strictEqual(res3._getStatusCode(), 200);
    assert.deepStrictEqual(res3._getData().poll.name, 'protein');
    assert.deepStrictEqual(res3._getData().poll.options, 
      ['chicken', 'beef', 'pork']);

    const req4 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPoll',
       body: {name: 'carb', time: 7,
        options: ['rice', 'bread', 'tortilla']}});
    const res4 = httpMocks.createResponse();
    addPoll(req4, res4);
    assert.strictEqual(res4._getStatusCode(), 200);
    assert.deepStrictEqual(res4._getData().poll.name, 'carb');
    assert.deepStrictEqual(res4._getData().poll.options,
      ['rice', 'bread', 'tortilla']);
    
    // NOTE: protein goes first because it finishes sooner
    const req5 = httpMocks.createRequest(
      {method: 'GET', url: '/api/listPolls', query:{}});
    const res5 = httpMocks.createResponse();
    listPolls(req5, res5);
    assert.strictEqual(res5._getStatusCode(), 200);
    assert.deepStrictEqual(res5._getData().polls.length, 3);
    assert.deepStrictEqual(res5._getData().polls[0].name, 'protein');
    assert.deepStrictEqual(res5._getData().polls[1].name, 'carb');
    assert.deepStrictEqual(res5._getData().polls[2].name, 'lunch');

    // push time forward for all by over 5 minutes
    advanceTimeForTesting(5 * 60 * 1000 + 50);

    // NOTE: protein goes after because it has finished
    const req6 = httpMocks.createRequest(
      {method: 'GET', url: '/api/listPolls', query:{}});
    const res6 = httpMocks.createResponse();
    listPolls(req6, res6);
    assert.strictEqual(res6._getStatusCode(), 200);
    assert.deepStrictEqual(res6._getData().polls.length, 3);
    assert.deepStrictEqual(res6._getData().polls[0].name, 'carb');
    assert.deepStrictEqual(res6._getData().polls[1].name, 'lunch');
    assert.deepStrictEqual(res6._getData().polls[2].name, 'protein');
    
    // push time forward by 4 minutes
    advanceTimeForTesting(4 * 60 * 1000);

    //NOTE: protein stays after because it finished first
    const req7 = httpMocks.createRequest(
      {method: 'GET', url: '/api/listPolls', query:{}});
    const res7 = httpMocks.createResponse();
    listPolls(req7, res7);
    assert.strictEqual(res7._getStatusCode(), 200);
    assert.deepStrictEqual(res7._getData().polls.length, 3);
    assert.deepStrictEqual(res7._getData().polls[0].name, 'lunch');
    assert.deepStrictEqual(res7._getData().polls[1].name, 'carb');
    assert.deepStrictEqual(res7._getData().polls[2].name, 'protein');

    // push time forward by another 4 minutes
    advanceTimeForTesting(4 * 60 * 1000);

    //Note: protein stays after because it finished first
    const req8 = httpMocks.createRequest(
      {method: 'GET', url: '/api/listPolls', query:{}});
    const res8 = httpMocks.createResponse();
    listPolls(req8, res8);
    assert.strictEqual(res8._getStatusCode(), 200);
    assert.deepStrictEqual(res8._getData().polls.length, 3);
    assert.deepStrictEqual(res8._getData().polls[0].name, 'lunch');
    assert.deepStrictEqual(res8._getData().polls[1].name, 'carb');
    assert.deepStrictEqual(res8._getData().polls[2].name, 'protein');

    resetForTesting();
  });

  it('addPoll', function() {
    // First branch: missing name parameter error case
    const req1 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPoll', body: {}})
    const res1 = httpMocks.createResponse();
    addPoll(req1, res1);
    assert.strictEqual(res1._getStatusCode(), 400);
    assert.deepStrictEqual(res1._getData(), "missing 'name' parameter");

    // Second branch: invalid time input error case
      // missing time
    const req2 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPoll', 
        body: {name: 'protein'}})
    const res2 = httpMocks.createResponse();
    addPoll(req2, res2);
    assert.strictEqual(res2._getStatusCode(), 400);
    assert.deepStrictEqual(res2._getData(), `'time' is not a number: ${undefined}`);
    
      // invalid time
    const req5 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPoll',
        body: {name: 'protein', time: '5'}});
    const res5 = httpMocks.createResponse();
    addPoll(req5, res5);
    assert.strictEqual(res5._getStatusCode(), 400);
    assert.deepStrictEqual(res5._getData(), `'time' is not a number: ${'5'}`);

    const req3 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPoll',
        body: {name: 'protein', time: 0}});
    const res3 = httpMocks.createResponse();
    addPoll(req3, res3);
    assert.strictEqual(res3._getStatusCode(), 400);
    assert.deepStrictEqual(res3._getData(), "'time' is not a positive integer: 0");

    const req6 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPoll',
        body: {name: 'protein', time: -1}});
    const res6 = httpMocks.createResponse();
    addPoll(req6, res6);
    assert.strictEqual(res6._getStatusCode(), 400);
    assert.deepStrictEqual(res6._getData(), "'time' is not a positive integer: -1")

    // Third branch: invalid options input error case
    const req4 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPoll',
        body: {name: 'protein', time: 1}});
    const res4 = httpMocks.createResponse();
    addPoll(req4, res4);
    assert.strictEqual(res4._getStatusCode(), 400);
    assert.deepStrictEqual(res4._getData(), `'options' is not an array: ${undefined}`);
    
    const req7 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPoll',
        body: {name: 'protein', time: 1, options: ''}});
    const res7 = httpMocks.createResponse();
    addPoll(req7, res7);
    assert.strictEqual(res7._getStatusCode(), 400);
    assert.deepStrictEqual(res7._getData(), "'options' is not an array: ");

    // Fourth branch: poll already saved error case
    const req8 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPoll',
        body: {name: 'protein', time: 1, options: ['chicken', 'beef']}});
    const res8 = httpMocks.createResponse();
    addPoll(req8, res8);

    const req9 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPoll',
        body: {name: 'protein', time: 1, options: ['chicken', 'beef']}});
    const res9 = httpMocks.createResponse();
    addPoll(req9, res9);
    assert.strictEqual(res9._getStatusCode(), 400);
    assert.deepStrictEqual(res9._getData(), "poll for 'protein' already exists");


    const req10 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPoll',
        body: {name: 'carb', time: 1, options: ['rice', 'bread']}});
    const res10 = httpMocks.createResponse();
    addPoll(req10, res10);

    const req11 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPoll',
        body: {name: 'carb', time: 1, options: ['rice', 'bread']}});
    const res11 = httpMocks.createResponse();
    addPoll(req11, res11);
    assert.strictEqual(res11._getStatusCode(), 400);
    assert.deepStrictEqual(res11._getData(), "poll for 'carb' already exists");
    
    // Correctly added:
    const req12 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPost',
        body: {name: 'lunch', time: 2, options: ['pizza', 'burger']}});
    const res12 = httpMocks.createResponse();
    addPoll(req12, res12);
    assert.strictEqual(res12._getStatusCode(), 200);
    assert.deepStrictEqual(res12._getData().poll, 
      {name: 'lunch', time: Date.now() + 2 * 60 * 1000, 
        options: ['pizza', 'burger']});

    const req13 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPost',
        body: {name: 'dinner', time: 10, options: ['pasta', 'cake']}});
    const res13 = httpMocks.createResponse();
    addPoll(req13, res13);
    assert.strictEqual(res13._getStatusCode(), 200);
    assert.deepStrictEqual(res13._getData().poll, 
      {name: 'dinner', time: Date.now() + 10 * 60 * 1000, 
        options: ['pasta', 'cake']});
    resetForTesting();
  })

  it('getPoll', function() {
    // First branch: missign name parameter error case
    const req1 = httpMocks.createRequest(
      {method: 'GET', url: '/api/getPoll', query: {}});
    const res1 = httpMocks.createResponse();
    getPoll(req1, res1);
    assert.strictEqual(res1._getStatusCode(), 400);
    assert.deepStrictEqual(res1._getData(), "missing or invalid 'name' parameter");

    const req2 = httpMocks.createRequest(
      {method: 'GET', url: '/api/getPoll', query: {name: 1}});
    const res2 = httpMocks.createResponse();
    getPoll(req2, res2);
    assert.strictEqual(res2._getStatusCode(), 400);
    assert.deepStrictEqual(res2._getData(), "missing or invalid 'name' parameter");

    // Second branch: poll not saved error case
    const req3 = httpMocks.createRequest(
      {method: 'GET', url: '/api/getPoll', query: {name: 'lunch'}});
    const res3 = httpMocks.createResponse();
    getPoll(req3, res3);
    assert.strictEqual(res3._getStatusCode(), 400);
    assert.deepStrictEqual(res3._getData(), "no poll with name 'lunch'");

    const req4 = httpMocks.createRequest(
      {method: 'GET', url: '/api/getPoll', query: {name: 'dinner'}});
    const res4 = httpMocks.createResponse();
    getPoll(req4, res4);
    assert.strictEqual(res4._getStatusCode(), 400);
    assert.deepStrictEqual(res4._getData(), "no poll with name 'dinner'");

    // Straight line code:
    const req5 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPost',
        body: {name: 'lunch', time: 2, options: ['pizza', 'burger']}});
    const res5 = httpMocks.createResponse();
    addPoll(req5, res5);
    const req6 = httpMocks.createRequest(
      {method: 'GET', url: '/api/getPoll', query: {name: 'lunch'}});
    const res6 = httpMocks.createResponse();
    getPoll(req6, res6);
    assert.strictEqual(res6._getStatusCode(), 200);
    assert.deepStrictEqual(res6._getData().poll, 
      {name: 'lunch', time: Date.now() + 2 * 60 * 1000, 
        options: ['pizza', 'burger']});

    const req7 = httpMocks.createRequest(
      {method: 'POST', url: '/api/addPost',
        body: {name: 'dinner', time: 10, options: ['pasta', 'cake']}});
    const res7 = httpMocks.createResponse();
    addPoll(req7, res7);
    const req8 = httpMocks.createRequest(
      {method: 'GET', url: '/api/getPoll', query: {name: 'dinner'}});
    const res8 = httpMocks.createResponse();
    getPoll(req8, res8);
    assert.strictEqual(res8._getStatusCode(), 200);
    assert.deepStrictEqual(res8._getData().poll, 
      {name: 'dinner', time: Date.now() + 10 * 60 * 1000, 
        options: ['pasta', 'cake']});
    
    resetForTesting();
  })
});
