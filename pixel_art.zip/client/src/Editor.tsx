import React, { Component, ChangeEvent, MouseEvent } from "react";
import { Square, Path, solid, toColor, replace, find, split } from './square';
import { SquareElem } from "./square_draw";
import { nil, rev } from "./list";

type EditorProps = {
  /** Initial state of the file. */
  initialState: Square;
  onSave: (sq: Square) => void;
  onBack: () => void;
};


type EditorState = {
  /** The root square of all squares in the design */
  root: Square;

  /** Path to the square that is currently clicked on, if any */
  selected?: Path;

  currColor?: string;
};


/** UI for editing the image. */
export class Editor extends Component<EditorProps, EditorState> {

  constructor(props: EditorProps) {
    super(props);

    this.state = { root: props.initialState };
  }

  render = (): JSX.Element => {
    if (this.state.selected === undefined) {
      return <div><span><SquareElem width={600} height={600} square={this.state.root} 
        selected={undefined} onClick={this.doSquareClick}></SquareElem>
              {<button value='save' onClick={this.doSaveClick}>Save</button>}
              {<button value='back' onClick={this.doBackClick}>Close</button>}
          </span></div>
    } else {
      return <div> <span><SquareElem width={600} height={600}
            square={this.state.root} selected={this.state.selected}
            onClick={this.doSquareClick}></SquareElem>
                  {<button value='split' onClick={this.doSplitClick}>Split</button>}
                  {<button value='merge' onClick={this.doMergeClick}>Merge</button>}
                  {<select value={this.state.currColor} onChange={this.doColorChange}>
                  <option value='blue'>blue</option>
                  <option value='green'>green</option>
                  <option value='orange'>orange</option>
                  <option value='purple'>purple</option>
                  <option value='red'>red</option>
                  <option value='white'>white</option>
                  <option value='yellow'>yellow</option>
                  </select>}
                  {<button value='save' onClick={this.doSaveClick} >Save</button>}
                  {<button value='back' onClick={this.doBackClick} >Close</button>}
            </span>
                  </div>
    }
  };

  doSquareClick = (path: Path): void => {
    const sq = find(this.state.root, path);
    if (sq !== undefined && sq.kind === 'solid') {
      this.setState({root: this.state.root, selected: path, currColor: sq.color});
    }
  }

  doSplitClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
    if (this.state.selected !== undefined) {
      const sq = find(this.state.root, this.state.selected);
      if (sq !== undefined) {
      this.setState({root: replace(this.state.root, this.state.selected,
        split(sq, sq, sq, sq)), selected: undefined})
      }
    }
  };

  doMergeClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
    if (this.state.selected !== undefined) {
      const sq = find(this.state.root, this.state.selected);
      if (sq !== undefined) {
        this.setState({root: replace(this.state.root, mergeHelp(this.state.selected), sq),
          selected: undefined});
      }
    }
  };

  doColorChange = (_evt: ChangeEvent<HTMLSelectElement>): void => {
    if (this.state.selected !== undefined)
      this.setState({root: replace(this.state.root, this.state.selected, 
        solid(toColor(_evt.target.value))), selected: undefined});
  };

  doSaveClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
    this.props.onSave(this.state.root);
  }

  doBackClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
    this.props.onBack();
  }

}

const mergeHelp = (p: Path): Path => {
  const mergePath = rev(p);
  if (mergePath !== nil) {
    return rev(mergePath.tl);
  }
  return nil;
}
