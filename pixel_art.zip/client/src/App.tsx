import React, { ChangeEvent, Component, MouseEvent } from "react";
import { Square, fromJson, solid, toJson } from './square';
import { Editor } from "./Editor";
import { isRecord } from "./record";
import { SquareNodeElem } from "./square_draw";

type AppState = {
  // will probably need something here
  savesPage: boolean;
  squareName?: string;
  list?: JSX.Element[];
  loaded?: Square;
};


export class App extends Component<{}, AppState> {

  constructor(props: {}) {
    super(props);

    this.state = {savesPage: true};
  }

  render = (): JSX.Element => {
    if (this.state.savesPage) {
      if (this.state.list === undefined) {
        this.componentDidMount;
      }
    return (<div><h3>Files:</h3>
              <div>
                <ul id='files'>
                  {this.state.list}
                </ul>
              </div>
              <p>Name: 
              <input type='text' value={this.state.squareName} onChange={this.doInputChange}></input>
              <button type='submit' onClick={this.doSubmitClick}>Submit</button>
              </p></div>);

    } else {
      if (this.state.loaded === undefined) {
        const sq = solid('white');
        return <Editor initialState={sq} 
                      onSave={this.doSaveClick} 
                      onBack={this.doBackClick}/>
      } else {
        return <Editor initialState={this.state.loaded} 
                      onSave={this.doSaveClick}
                      onBack={this.doBackClick}/>
      }
    }
  };

  // TODO: add some functions to access routes and handle state changes probably
  doInputChange = (_evt: ChangeEvent<HTMLInputElement>): void => {
    this.setState({squareName: _evt.target.value});
  }

  doSubmitClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
    this.setState({savesPage: false });
  }

  doSaveClick = (sq: Square): void => {
    if (this.state.squareName !== undefined) {
      fetch('/api/save', {method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({name: this.state.squareName, value: toJson(sq)})})
      .then()
      .catch(() => this.doListError('failed to connect'));
    }
    this.componentDidUpdate;
  }

  doBackClick = (): void => {
    this.setState({savesPage: true, squareName: undefined});
    this.componentDidUpdate;
  }

  componentDidMount = (): void => {
    fetch('/api/list')
    .then(this.doListResp)
    .catch(() => this.doListError('failed to connect'));
  }

  componentDidUpdate = (_preProps: Readonly<{}>, _prevState: Readonly<AppState>): void => {
      fetch('/api/list')
      .then(this.doListResp)
      .catch(() => this.doListError('failed to connect'));
  }
  
  doListError = (err: string): void => {
    console.error(err);
  }

  doListResp = (res: Response): void => {
    if (res.status === 200) {
      res.json().then(this.doListJson)
          .catch(() => this.doListError('there are no current saves'));
    }
  }

  doListJson = (files: unknown): void => {
    if (!isRecord(files)) {
      console.error('not a record', files);
      return;
    } else if (Array.isArray(files.names)) {
      let newList = [ ];
      for (const name of files.names) {
        newList.push(<a href='#' onClick={(e) => this.doLoadClick(e, name)} ><li key={name}>{name}</li></a>);
      }
      this.setState({list: newList});
    } else {
      console.error('not an array', files.names);
      return;
    }
  }

  doLoadClick = (_evt: MouseEvent<HTMLAnchorElement>, name: string): void => {
    _evt.preventDefault();
    if (name !== undefined) {
    fetch('/api/load?' + name)
      .then(this.doLoadResp)
      .catch(() => this.doListError('faild to connect'));
      console.log('doLoadClick');
    } else {
      console.log('undefined');
    }
  }

  doLoadResp = (res: Response): void => {
    if (res.status === 200) {
      res.json().then(this.doLoadJson)
        .catch(() => this.doListError('invalid name'));
      console.log('doLoadResp');
    } else if (res.status === 400) {
      console.log('undefined');
    } else {
      console.log('not saved');
    }
  }

  doLoadJson = (sq: unknown): void => {
    if (!isRecord(sq)) {
      console.error('not a record', sq);
    } else if (sq.value === SquareNodeElem) {
      this.setState({savesPage: false, loaded: fromJson(sq.value)})
      console.log('doLoadJson');
    }
  }
}
