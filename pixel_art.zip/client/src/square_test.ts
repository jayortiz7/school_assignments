import * as assert from 'assert';
import { solid, split, toJson, fromJson, find, Path, replace } from './square';
import { cons, nil } from './list';


describe('square', function() {

  it('toJson', function() {
    assert.deepEqual(toJson(solid("white")), "white");
    assert.deepEqual(toJson(solid("green")), "green");

    const s1 = split(solid("blue"), solid("orange"), solid("purple"), solid("white"));
    assert.deepEqual(toJson(s1),
      ["blue", "orange", "purple", "white"]);

    const s2 = split(s1, solid("green"), s1, solid("red"));
    assert.deepEqual(toJson(s2),
      [["blue", "orange", "purple", "white"], "green",
       ["blue", "orange", "purple", "white"], "red"]);

    const s3 = split(solid("green"), s1, solid("yellow"), s1);
    assert.deepEqual(toJson(s3),
      ["green", ["blue", "orange", "purple", "white"],
       "yellow", ["blue", "orange", "purple", "white"]]);
  });

  it('fromJson', function() {
    assert.deepEqual(fromJson("white"), solid("white"));
    assert.deepEqual(fromJson("green"), solid("green"));

    const s1 = split(solid("blue"), solid("orange"), solid("purple"), solid("white"));
    assert.deepEqual(fromJson(["blue", "orange", "purple", "white"]), s1);

    assert.deepEqual(
        fromJson([["blue", "orange", "purple", "white"], "green",
                 ["blue", "orange", "purple", "white"], "red"]),
        split(s1, solid("green"), s1, solid("red")));

    assert.deepEqual(
        fromJson(["green", ["blue", "orange", "purple", "white"],
                  "yellow", ["blue", "orange", "purple", "white"]]),
        split(solid("green"), s1, solid("yellow"), s1));
  });

});

describe('path', function() {
  it('find', function(){
    const s1 = solid('blue');
    const s2 = split(solid('blue'), solid('green'), solid('orange'), solid('purple'));
    const p1: Path = cons('NW', nil);
    const p2: Path = cons('NW', cons('SW', nil));

    // 0 recursive calls:
    assert.deepStrictEqual(find(s1, nil), s1);
    assert.deepStrictEqual(find(s2, nil), s2);
    assert.deepEqual(find(s1, p1), undefined); // undefined: invalid path or root

    // 1 recursive call:
    assert.deepStrictEqual(find(s2, p1), solid('blue'));
    assert.deepEqual(find(s2, p2), undefined); // undefined: invalid path or root
    const p3: Path = cons('NE', nil);
    const p4: Path = cons('SW', nil);
    const p5: Path = cons('SE', nil);
    assert.deepStrictEqual(find(s2, p3), solid('green'));
    assert.deepEqual(find(s2, cons('NE', cons('SE', nil))), undefined); // undefined: invalid path or root
    assert.deepStrictEqual(find(s2, p4), solid('orange'));
    assert.deepEqual(find(s2, cons('SE', cons('NE', nil))), undefined); // undefined: invalid path or root
    assert.deepStrictEqual(find(s2, p5), solid('purple'));
    assert.deepEqual(find(s2, cons('SW', cons('NW', nil))), undefined); // undefined: invalid path or root

    // many recursive calls:
    const s3 = split(s2, solid('blue'), solid('green'), solid('orange'));
    assert.deepStrictEqual(find(s3, cons('NW', cons('NW', nil))), solid('blue'));
    assert.deepEqual(find(s3, cons('NW', cons('NW', cons('NW', nil)))), undefined); // undefined: invalid path or root
    assert.deepStrictEqual(find(s3, cons('NW', cons('NE', nil))), solid('green'));
    assert.deepEqual(find(s3, cons('NW', cons('NE', cons('NE', nil)))), undefined); // undefined: invalid path or root
    assert.deepStrictEqual(find(s3, cons('NW', cons('SW', nil))), solid('orange'));
    assert.deepEqual(find(s3, cons('NW', cons('SW', cons('SW', nil)))), undefined); // undefined: invalid path or root
    assert.deepStrictEqual(find(s3, cons('NW', cons('SE', nil))), solid('purple'));
    assert.deepEqual(find(s3, cons('NW', cons('SE', cons('SE', nil)))), undefined); // undefined: invalid path or root
  });

  it('replace', function(){
    const s1 = solid('blue');
    const s2 = split(solid('blue'), solid('green'), solid('orange'), solid('purple'));
    const p1: Path = cons('NW', nil);
    const p2: Path = cons('NW', cons('SW', nil));

    // 0 recursive calls:
    assert.deepStrictEqual(replace(s1, nil, s2), s2);
    assert.deepStrictEqual(replace(s2, nil, s1), s1);
    assert.throws(() => replace(s1, p1, s2), Error('invalid path or root')); // error: invalid path or root

    // 1 recursive call:
    assert.deepStrictEqual(replace(s2, p1, s1), s2);
    assert.throws(() => replace(s2, p2, s1), Error('invalid path or root')); // error: invalid path or root
    const p3: Path = cons('NE', nil);
    const p4: Path = cons('SW', nil);
    const p5: Path = cons('SE', nil);

    assert.deepStrictEqual(replace(s2, p3, s1), split(solid('blue'), solid('blue'), 
      solid('orange'), solid('purple')));
    assert.throws(() => replace(s2, cons('NE', cons('NE', nil)), s1), 
      Error('invalid path or root')); // error: invalid path or root
    assert.deepStrictEqual(replace(s2, p4, s1), split(solid('blue'), solid('green'), 
      solid('blue'), solid('purple'))); 
    assert.throws(() => replace(s2, cons('SW', cons('SW', nil)), s1), 
      Error('invalid path or root')); // error: invalid path or root
    assert.deepStrictEqual(replace(s2, p5, s1), split(solid('blue'), solid('green'), 
      solid('orange'), solid('blue')));
    assert.throws(() => replace(s2, cons('SE', cons('SE', nil)), s1), 
      Error('invalid path or root')); // error: invalid path or root
    
    // many recursive calls:
    const s3 = split(s2, solid('blue'), solid('green'), solid('orange'));
    assert.deepStrictEqual(replace(s3, cons('NW', cons('NW', nil)), s1), s3);
    assert.throws(() => replace(s3, cons('NW', cons('NW', cons('NW', nil))), s1),
      Error('invalid path or root')); // error: invalid path or root
    assert.deepStrictEqual(replace(s3, cons('NW', cons('NE', nil)), s1), split(split(s1, s1, solid('orange'), solid('purple')),
      solid('blue'), solid('green'), solid('orange')));
    assert.throws(() => replace(s3, cons('NW', cons('NE', cons('NE', nil))), s1),
      Error('invalid path or root')); // error: invalid path or root
    assert.deepStrictEqual(replace(s3, cons('NW', cons('SW', nil)), s1), split(split(s1, solid('green'), s1, solid('purple')),
      solid('blue'), solid('green'), solid('orange')));
    assert.throws(() => replace(s3, cons('NW', cons('SW', cons('SW', nil))), s1),
      Error('invalid path or root')); // error: invalid path or root
    assert.deepStrictEqual(replace(s3, cons('NW', cons('SE', nil)), s1), split(split(s1, solid('green'), solid('orange'), s1),
      solid('blue'), solid('green'), solid('orange')));
    assert.throws(() => replace(s3, cons('NW', cons('SE', cons('SE', nil))), s1),
      Error('invalid path or root')); // error: invalid path or root
  });
});