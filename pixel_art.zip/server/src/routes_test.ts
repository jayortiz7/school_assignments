import * as assert from 'assert';
import * as httpMocks from 'node-mocks-http';
import { load, list, resetSaves, save } from './routes';


describe('routes', function() {

  // TODO: add tests for your routes
  it('save', function() {
    // First branch: error case 
    const req1 = httpMocks.createRequest(
      {method: 'POST', url: '/save', body: {value: 'some stuff'}});
    const res1 = httpMocks.createResponse();
    save(req1, res1);

    assert.strictEqual(res1._getStatusCode(), 400);
    assert.deepStrictEqual(res1._getData(), 
      'required argument "name" was missing');

    // Second branch, straight line code, error case (only one possible input)
    const req2 = httpMocks.createRequest(
      {method: 'POST', url: '/save', body: {name: "A"}});
    const res2 = httpMocks.createResponse();
    save(req2, res2);

    assert.strictEqual(res2._getStatusCode(), 400);
    assert.deepStrictEqual(res2._getData(),
      'required argument "value" was missing');

    // Third branch, straight line code
    const req3 = httpMocks.createRequest({method: 'POST', url: '/save',
        body: {name: "A", value: "some stuff"}});
    const res3 = httpMocks.createResponse();
    save(req3, res3);

    assert.strictEqual(res3._getStatusCode(), 200);
    assert.deepStrictEqual(res3._getData(), {replaced: false});

    const req4 = httpMocks.createRequest({method: 'POST', url: '/save',
        body: {name: "A", value: "different stuff"}});
    const res4 = httpMocks.createResponse();
    save(req4, res4);

    assert.strictEqual(res4._getStatusCode(), 200);
    assert.deepStrictEqual(res4._getData(), {replaced: true});

    resetSaves();
  })

  it('load', function() {
    resetSaves();
    // First Branch error case: undefined
    const req1 = httpMocks.createRequest(
      {method: 'GET', url: '/load', query: {}});
    const res1 = httpMocks.createResponse();
    load(req1, res1);

    assert.strictEqual(res1._getStatusCode(), 400);
    assert.deepStrictEqual(res1._getData(),
        'required argument "name" was missing');

    // First Branch error case: missign transcript
    const req6 = httpMocks.createRequest(
      {method: 'GET', url: '/load', query: {name: 'notsaved'}});
    const res6 = httpMocks.createResponse();
    load(req6, res6);

    assert.strictEqual(res6._getStatusCode(), 404);
    assert.deepStrictEqual(res6._getData(), 
        'required argument "name" was not previously saved');

    // Second Branch, staight line code
    const req2 = httpMocks.createRequest({methed: 'POST', url: '/save', 
      body: {name: 'dogs', value: 'dogs are cool'}});
    const res2 = httpMocks.createResponse();
    save(req2, res2);
    const req3 = httpMocks.createRequest({method: 'GET', url: '/load', 
      query: {name: 'dogs'}});
    const res3 = httpMocks.createResponse();
    load(req3, res3);

    assert.deepStrictEqual(res3._getData(), {value: 'dogs are cool'});

    const req4 = httpMocks.createRequest({method: 'POST', url: '/save', 
      body: {name: 'cats', value: 'I like cats more'}});
    const res4 = httpMocks.createResponse();
    save(req4, res4);
    const req5 = httpMocks.createRequest({method: 'GET', url: '/load', 
      query: {name: 'cats'}});
    const res5 = httpMocks.createResponse();
    load(req5, res5);

    assert.deepStrictEqual(res5._getData(), {value: 'I like cats more'});

    resetSaves();
  })

  it('list', function() {
    resetSaves();
    // First branch error case: empty Map
    const req1 = httpMocks.createRequest({method: 'GET', url: '/list'});
    const res1 = httpMocks.createResponse();

    list(req1, res1);
    assert.deepEqual(res1._getStatusCode(), 400);
    assert.deepStrictEqual(res1._getData(), 'there are no current saves');

    // Second branch: straight line code
    const req2 = httpMocks.createRequest({method: 'POST', url: '/save', 
      body: {name: 'first', value: 'first save to map'}});
    const res2 = httpMocks.createResponse();
    save(req2, res2);

    const req3 = httpMocks.createRequest({method: 'GET', url: '/list'});
    const res3 = httpMocks.createResponse();
    list(req3, res3);

    assert.deepEqual(res3._getStatusCode(), 200);
    assert.deepStrictEqual(res3._getData(), {names: ['first']});

    const req4 = httpMocks.createRequest({method: 'POST', url: '/save', 
      body: {name: 'second', value: 'second save to map'}});
    const res4 = httpMocks.createResponse();
    save(req4, res4);

    const req5 = httpMocks.createRequest({method: 'GET', url: '/list'});
    const res5 = httpMocks.createResponse();
    list(req5, res5);

    assert.deepEqual(res5._getStatusCode(), 200);
    assert.deepStrictEqual(res5._getData(), {names: ['first', 'second']});

    const req6 = httpMocks.createRequest({method: 'POST', url: '/save',
      body: {name: 'third', value: 'third save to map'}});
    const res6 = httpMocks.createResponse();
    save(req6, res6);

    const req7 = httpMocks.createRequest({method: 'GET', url: '/list'});
    const res7 = httpMocks.createResponse();
    list(req7, res7);

    assert.deepEqual(res7._getStatusCode(), 200);
    assert.deepStrictEqual(res7._getData(), {names: ['first', 'second', 'third']});
    
    resetSaves();
  })
});
