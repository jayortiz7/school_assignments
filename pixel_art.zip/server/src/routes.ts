import { Request, Response } from "express";
import { ParamsDictionary } from "express-serve-static-core";


// Require type checking of request body.
type SafeRequest = Request<ParamsDictionary, {}, Record<string, unknown>>;
type SafeResponse = Response;  // only writing, so no need to check

// A Map to record transcripts
const saves: Map<string, unknown> = new Map<string, unknown>();

/**
 * Handles requests for /save by storing given content
 * @param req save request containing name of save and content
 * @param res response to be returned to user
 * @returns error if name of save request is undefined or not a string or 
 *          error if value of save is undefined or 
 *          true if given name replaces previous save or
 *          false if given name does not replace previose save
 */
export const save = (req: SafeRequest, res: SafeResponse): void => {
  const name =  req.body.name;
  if (name === undefined || typeof name !== 'string') {
    res.status(400).send('required argument "name" was missing');
    return;
  }
  
  const value = req.body.value;
  if (value === undefined) {
    res.status(400).send('required argument "value" was missing');
    return;
  }

  if (saves.delete(name)) {
    saves.set(name, value);
    res.send({replaced: true});
  } else {
    saves.set(name, value);
    res.send({replaced: false});
  }
}

/**
 *  Handles requests for /load by returning the save with the given name
 * @param req load request containing the name of the save
 * @param res response to be returned to user
 * @returns error if name is undefined or 
 *          error if the given name is not a previous save or 
 *          the content of the save with given name
 */
export const load = (req: SafeRequest, res: SafeResponse): void => {
  const name = first(req.query.name);
  if (name === undefined) {
    res.status(400).send('required argument "name" was missing');
    return;
  } else if (!saves.has(name)) {
    res.status(404).send('required argument "name" was not previously saved');
  } else {
    res.send({value: saves.get(name)});
  }
}

/** Used in tests to set the Saves map back to empty */
export const resetSaves = (): void => {
  saves.clear();
}

/**
 * Handles requests for list of names of saves
 * @param req request of list of names
 * @param res response to be returned to user
 * @returns error if saves map is empty or
 *          list of names of saves in map
 */
export const list = (_req: SafeRequest, res: SafeResponse): void => {
  if (saves.size === 0) {
    res.status(400).send('there are no current saves');
    return;
  } else {
    res.send({names: toArray()});
  }
}

const toArray = (): string[] => {
  const names = saves.keys();
  let rec = [];
  for (const n of names) {
    rec.push(n);
  }
  return rec;
} 


// Helper to return the (first) value of the parameter if any was given.
// (This is mildly annoying because the client can also give mutiple values,
// in which case, express puts them into an array.)
const first = (param: unknown): string|undefined => {
  if (Array.isArray(param)) {
    return first(param[0]);
  } else if (typeof param === 'string') {
    return param;
  } else {
    return undefined;
  }
};
