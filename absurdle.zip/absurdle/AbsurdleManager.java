import java.util.*;

public class AbsurdleManager {
    private Set<String> wordList;
    private int maxLength;
    private static Map<Character, Integer> counts;


    public AbsurdleManager(Collection<String> dictionary, int length) {
        if (length < 1) {
            throw new IllegalArgumentException();
        } else {
            maxLength = length;
            wordList = new TreeSet<String>();
            for (String temp : dictionary) {
                if (temp.length() == length) {
                    wordList.add(temp);
                }
            }
        }
    }

    public Set<String> words() {
        return wordList;
    }

    // The comment for this method is provided. Do not modify this comment:
    // Params:
    //  String word -- the secret word trying to be guessed. Assumes word is made up of only
    //                 lower case letters and is the same length as guess.
    //  String guess -- the guess for the word. Assumes guess is made up of only
    //                  lower case letters and is the same length as word.
    // Exceptions:
    //   none
    // Returns:
    //   returns a string, made up of gray, yellow, or green squares, representing a
    //   standard wordle clue for the provided guess made against the provided secret word.
    public static String patternFor(String word, String guess) {
        counts = new TreeMap<>();
        count(word);
        String[] pattern = patternHelp(word, guess, counts);
        String newPattern = "";
        for (int i = 0; i < pattern.length; i++) {
            newPattern += pattern[i];
        }
        return newPattern;
    }

    public String record(String guess) {
        if (wordList.isEmpty()) {
            throw new IllegalStateException();
        } else if (guess.length() < maxLength) {
            throw new IllegalArgumentException();
        } else {
            Map<String, Set<String>> patternMap = new TreeMap<>();
            for (String temp1 : wordList) {
                Set<String> patternSet = new TreeSet<>();
                if (!patternMap.containsValue(temp1)) {
                    String pattern1 = patternFor(temp1, guess);
                    for (String temp2 : wordList) {
                         String pattern2 = patternFor(temp2, guess);
                         if (pattern2.equals(pattern1)) {
                             patternSet.add(pattern2);
                         }
                    }
                    patternMap.put(pattern1, patternSet);
                }
            }
            return updateList(patternMap);
        }
    }

    private String updateList(Map<String, Set<String>> patternMap) {
        int setSize = 0;
        String newPattern = "";
        for (String temp : patternMap.keySet()) {
            if (patternMap.get(temp).size() > setSize) {
                setSize = patternMap.get(temp).size();
                newPattern = temp;
            }
        }
        wordList = patternMap.get(newPattern);
        return newPattern;
    }

    // private String patternCheck(String temp, String guess, Map<String, Set<String>> patternMap) {
    //     if (!patternMap.containsValue(temp)) {
    //         return patternFor(temp, guess);
    //     }
    //     return null;
    // }

    private static void count(String str) {
        for (int i = 0; i < str.length(); i++) {
            if (!counts.containsKey(str.charAt(i))) {
                counts.put(str.charAt(i), 1);
            } else {
                counts.put(str.charAt(i), counts.get(str.charAt(i)) + 1);
            }
        }
    }

    private static String[] patternHelp (String word, String guess, Map<Character, Integer> counts) {
        String[] newPattern = new String[word.length()];
        for (int i = 0; i < word.length(); i++) {
            if (guess.charAt(i) == word.charAt(i)) {
                newPattern[i] = "G";
                counts.put(guess.charAt(i), counts.get(guess.charAt(i)) - 1);
            }
        }
        for (int i = 0; i < word.length(); i++) {
            if (guess.charAt(i) != word.charAt(i) && counts.containsKey(guess.charAt(i))
                && counts.get(guess.charAt(i)) > 0) {
                newPattern[i] = "Y";
                counts.put(guess.charAt(i), counts.get(guess.charAt(i)) - 1);
            } else if (newPattern[i] == null) {
                newPattern[i] = "g";
            }
        }
        return newPattern;
    }
}